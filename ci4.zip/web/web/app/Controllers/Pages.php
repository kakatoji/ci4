<?php

namespace App\Controllers;

class Pages extends BaseController
{
	public function index()
	{
	  $data=[
	    "title" => "Home | web informasi"
	    ];
		return view('pages/home',$data);
	}
	
	public function about()
	{
	  $data=[
	    "title" => "About me"
	    ];
		return view('pages/about',$data);
	}
	public function crypto()
	{
	  $data=[
	    "title" => "Crypto currency"
	    ];
	  
		return view('pages/crypto',$data);
	}
	public function script()
	{
	  $data=[
	    "title" => "Script | Bot"
	    ];
		return view('pages/script',$data);
	}
	public function tools()
	{
	  $data=[
	    "title" => "Tools"
	    ];
		return view('pages/tools',$data);
	}
}
